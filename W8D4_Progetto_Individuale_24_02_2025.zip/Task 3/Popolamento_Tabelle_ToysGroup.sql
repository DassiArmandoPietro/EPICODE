-- Popolamento della tabella CATEGORIA

INSERT INTO CATEGORIA (NOME_CATEGORIA) VALUES
('Bikes'),
('Clothing'),
('Accessories');

-- Popolamento della tabella PRODOTTO

INSERT INTO PRODOTTO (ID_CATEGORIA, NOME, PREZZO, DESCRIZIONE) VALUES
(1, 'Bike-100', 500.00, 'Mountain Bike'),
(1, 'Bike-200', 700.00, 'Road Bike'),
(2, 'Bike Glove M', 20.00, 'Medium Size Gloves'),
(2, 'Bike Glove L', 20.00, 'Large Size Gloves'),
(3, 'Water Bottle', 10.00, '750ml Bottle');

-- Popolamento della tabella REGIONE

INSERT INTO REGIONE (NOME_REGIONE) VALUES
('WestEurope'),
('SouthEurope');

-- Popolamento della tabella PAESE

INSERT INTO PAESE (ID_REGIONE, NOME_PAESE) VALUES
(1, 'France'),
(1, 'Germany'),
(2, 'Italy'),
(2, 'Greece');

-- Popolamento della tabella VENDITE

INSERT INTO VENDITE (ID_PRODOTTO, ID_PAESE, DATA_VENDITA, QUANTITA, IMPORTO_TOTALE) VALUES
(1, 1, '2025-01-10', 10, 5000.00),
(2, 2, '2025-01-15', 5, 3500.00),
(3, 3, '2025-01-20', 8, 160.00),
(4, 4, '2025-01-25', 12, 240.00),
(5, 1, '2025-02-01', 15, 150.00);