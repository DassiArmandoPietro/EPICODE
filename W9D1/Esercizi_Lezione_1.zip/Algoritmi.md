1° Algoritmo: Accensione del gas della cucina
--------------------------------------------------------------------------------------------------------------------------------------------------------
1) Raggiungere la cucina.
2) Avvicinarsi ai fornelli.
3) Premere la manopola del fornello interessato per azionare la scintilla necessaria all’emissione della fiamma.
4) Girare la manopola per regolare l’intensità della fiamma come desiderato.
5) Se il gas non si accende, riprovare l’accensione come descritto al punto 3.
6) Se dopo più tentativi il gas non si accende, verificare:
7) Che la bombola del gas non sia vuota (se applicabile).
8) Che la valvola principale del gas sia aperta.
9) Che il fornello non sia ostruito.
10) Una volta accesa la fiamma, verificare che rimanga stabile.

2° Algoritmo: Accensione auto
--------------------------------------------------------------------------------------------------------------------------------------------------------
1) Raggiungere l’auto.
2) Aprire la porta del conducente.
3) Salire sul sedile del guidatore.
4) Inserire la chiave nell’apposita fessura per l’accensione del veicolo.
5) Assicurarsi che l’auto sia in folle (oppure premere la frizione fino in fondo per evitare che l’auto sobbalzi e si spenga la batteria).
6) In base alla superficie su cui è parcheggiata l’auto (piana o pendente), tenere premuto anche il pedale del freno.
7) Girare la chiave verso destra fino all’accensione del motore.
8) Rilasciare la chiave e verificare che il motore sia partito correttamente.

3° Algoritmo: Andare a nuotare
--------------------------------------------------------------------------------------------------------------------------------------------------------
1) Raggiungere l’impianto natatorio.
2) Entrare nello spogliatoio pertinente al proprio sesso.
3) Se richiesto, togliersi le scarpe nell’apposita area delimitata ed indossare le ciabatte prima di raggiungere le cabine.
4) Entrare in una cabina, spogliarsi ed indossare il costume da bagno.
5) Riporre i propri indumenti sugli attaccapanni o in uno degli armadietti disponibili.
6) Per igiene, farsi una doccia prima di tuffarsi in piscina.
7) Effettuare un breve riscaldamento di 5-10 minuti.
8) Entrare in piscina evitando di tuffarsi, se vietato.
9) Iniziare a nuotare optando per lo stile desiderato.
10) Terminata l’attività, uscire dalla piscina e farsi una doccia prima di rivestirsi.


```python

```
